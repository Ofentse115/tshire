<?php 

if(isset($_POST['submit'])){

    $Firstname = mysqli_real_escape_string(Conn,$_POST['Firstname']);
	$Lastname = mysqli_real_escape_string(Conn,$_POST['Lastname']);
	$Gender = mysqli_real_escape_string(Conn,$_POST['Gender']);
	$Birthday = mysqli_real_escape_string(Conn,$_POST['Birthday']);
	$Email = mysqli_real_escape_string(Conn,$_POST['Email']);
	$Occupations = mysqli_real_escape_string(Conn,$_POST['Occupations']);
	$SalaryRange = mysqli_real_escape_string(Conn,$_POST['SalaryRange']);
	$ProfilePhoto = mysqli_real_escape_string(Conn,$_POST['ProfilePhoto']);
    $Resumes = mysqli_real_escape_string(Conn,$_POST['Resumes']);
}
$dbServername="localhost";
$dbUsername="root";
$dbPassword="";
$dbName="AlphaDB";


$Conn= mysqli_connect($dbServername,$dbUsername,$dbPassword,$dbName);


     if (empty($Firstname) || empty($Lastname) || empty($Gender) || empty($Birthday) || empty($Email) || empty($Occupations) || empty($SalaryRange) || empty($ProfilePhoto) || empty(Resumes) ){
		 
        	header("Location: ../new.php?new=success");
			exit();
	 }
 $sql= "insert into alpharegister(Firstname,Lastname,Gender,Birthday,Email,Occupations,SalaryRange,ProfilePhoto,Resumes) values('$Firstname','$Lastname','$Gender','$Birthday','$Email','$Occupations','$SalaryRange','$ProfilePhoto','$Resumes');";
				$query= mysqli_query($Conn,$sql);
				 if($query)
				 {
					 echo"<h3> Successfully saved</h3>";
				 }
				 else
				 {
					 echo"<h3> check for trouble</h3>";
				 }
