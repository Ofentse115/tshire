<?php


        	header("Location: ../new.php?new=empty")
                exit();

     }

     else

     {
      if(!preg_match("/^[a-zA-Z]*$/",$Firstname || !preg_match("/^[a-zA-Z]*$",$Lastname ))
         header("Location: ../new.php?new=invalid")
                exit();
     }
         else
         {
             if(filter_var($Email, filter_validate_email))
			 {
				header("Location: ../new.php?new=email")
                exit();
			 }
			 else
			 {
				
				 header("Location: ../new.php?new= success")
                exit();
			 }
         }




}



else{
	header("Location: ../new.php")
	exit();
}