<!DOCTYPE html>

<html>
	<head>
		<TITLE>Alpha Direct</TITLE>
		<link rel="stylesheet" type="text/css" href="style.css">
		<script type="text/javascript">
		
		function validate()
		{
			var Firstname = document.getElementById("name");
			var Lastname = document.getElementById("name");
			var Birthday = document.getElementById("name");
			var Email = document.getElementById("name");
			var Occupations = document.getElementById("name");
			var Salary range = document.getElementById("name");
			var Firstname = document.getElementById("name");
		}
		
		</script>
	</head>

       <body>
       	     <H1>ALPHA DIRECT</H1>
       	     <DIV class="register">
                                                 <h2>REGISTER HERE</h2>

       	     	<form method="POST" id="register" action="includes/dbConn.php"> 
       	     		<label> FIRSTNAME:</label>
                            <input type="text" name="Firstname" id="name" placeholder="Please enter your Firstname"><br><br><br>
       	     		<label> LASTNAME:</label>
                            <input type="text" name="Lastname" id="name" placeholder="Please enter your lastname"><br><br><br>
       	     		<label> GENDER:</label>
                            <input type="radio" name="Gender" value="male" checked> Male
                             <input type="radio" name="Gender" value="female"> Female<br><br><br>
       	     		<label> BIRTHDAY:</label>
                            <input type="datetime-local" id="name"><br><br><br>
       	     		<label> EMAIL:</label>
                            <input type="text" name="Email" id="name" placeholder="Please enter your email"><br><br><br>
       	     		<label> OCCUPATION:</label>
                            <select name="Occupations" id="name">
                              <option value="Ex student">Ex student </option>
                              <option value="Engineer">Engineer</option>
                              <option value="Programmer">Programmer</option>
                            </select><br><br><br>
       	     		<label> SALARY RANGE:</label>
                            <select name="Salary range" id="name">
                              <option value="0-2500BWP">0-2500BWP</option>
                              <option value="2501-5000BWP">2501-5000BWP</option>
                            </select><br><br><br>
       	     		<label> PROFILE PHOTO:</label>
					         <input type="file" name="pic" accept="image/*"><br><br><br>
       	     		<label> UPLOAD RESUME:</label>
                             <input type="file" name="doc" accept="file_extension"><br><br><br>
                            <input type="submit" value="Submit" id="submi">
       	     		

       	     	</form>
       	     </DIV>


       </body>

</html>
